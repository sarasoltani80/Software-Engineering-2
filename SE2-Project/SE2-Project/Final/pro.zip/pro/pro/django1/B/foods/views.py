from django.shortcuts import render
from .models import food

# Create your views here.

def show_food(request):
    food_list = food.objects.all()
    context={'food' : food_list}
    return render(request , 'index.html' , context)

def detail_food(request , food_id):
    food1 = food.objects.get(id = food_id)
    context = {'food': food1}
    return render(request, 'detail.html', context)
