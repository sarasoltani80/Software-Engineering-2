from django import forms

class CommentForm(forms.Form):
    name = forms.CharField(max_length=500)
    email = forms.EmailField(max_length=256)
    message = forms.CharField(max_length=500)