from django.shortcuts import render
from .models import Blog , Tag, Category , Comment
from .forms import CommentForm
from django.core.paginator import Paginator

def show_blog(request):
    blogs = Blog.objects.all()
    paginator = Paginator(blogs , 3)
    #show 6 blogs in each page

    page_number = request.GET.get('page')
    #user enters the page number that wants and shows it in url

    blog_list = paginator.get_page(page_number)
    #returns each blog refers to each page. returns blogs for first page , second page , ...

    context = {'blog' : blog_list}
    return render(request , 'show_blog.html' , context)

def detail_blog(request , blog_id):
    blog = Blog.objects.get(id = blog_id)
    tag = Tag.objects.all().filter(blog=blog)
    # blog is related name of field tags in Blog class
    recentpost = Blog.objects.all().order_by('-created_at')[:4]
    category = Category.objects.all().filter(blog=blog)
    comments = Comment.objects.all().filter(blog = blog)

    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            new_comment = Comment(blog= blog , name = cd['name'] , email = cd['email'] , message = cd['message'])
            new_comment.save()

    context = {'blog' : blog,
               'tags' : tag,
               'recent': recentpost,
               'category' : category,
               'comments' : comments,
               }
    return render(request , 'detail_blog.html' , context)

def filter_tag(request , tag):
    blogs = Blog.objects.all().filter(Tag__slug=tag)
    context = {
        'blog' : blogs
    }
    return render(request, 'show_blog.html', context)

def filter_category(request , category):
    blogs = Blog.objects.all().filter(category__slug=category)
    context = {
        'blog': blogs
    }
    return render(request, 'show_blog.html', context)

