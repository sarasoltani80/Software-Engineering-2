from django.urls import path
from . import views

#app_name = 'foods'

urlpatterns =[
    path('', views.show_food, name='show'),
    path('<int:food_id>/', views.detail_food, name='detail'),
]